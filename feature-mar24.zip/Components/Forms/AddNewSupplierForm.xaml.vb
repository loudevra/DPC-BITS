Namespace DPC.Components.Forms
    Public Class AddNewSupplierForm
        Public Event CloseRequested As EventHandler

        Public Sub New()
            InitializeComponent()
        End Sub

        Private Sub ClosePopup(sender As Object, e As RoutedEventArgs)
            RaiseEvent CloseRequested(Me, EventArgs.Empty)
        End Sub

        Private Sub AddSupplier(sender As Object, e As RoutedEventArgs)
            MessageBox.Show("Supplier Added Successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information)
            RaiseEvent CloseRequested(Me, EventArgs.Empty)
        End Sub
    End Class
End Namespace