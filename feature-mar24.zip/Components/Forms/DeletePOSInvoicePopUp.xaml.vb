﻿Namespace DPC.Components.Forms
    Public Class DeletePOSInvoicePopUp
        Private Sub New()

            ' This call is required by the designer.
            InitializeComponent()

            ' Add any initialization after the InitializeComponent() call.

        End Sub
    End Class
End Namespace
