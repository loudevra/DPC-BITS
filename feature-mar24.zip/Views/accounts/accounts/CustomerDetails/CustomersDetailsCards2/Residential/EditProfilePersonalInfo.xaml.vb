﻿Namespace DPC.Views.Accounts.Accounts.CustomerDetails.CustomersDetailsCards2.Residential
    Public Class EditProfilePersonalInfo
        Public Sub New()
            ' This call is required by the designer.
            InitializeComponent()
            ' Add any initialization after the InitializeComponent() call.
        End Sub
    End Class
End Namespace
