﻿Imports System.Collections.ObjectModel
Imports System.ComponentModel
Imports System.Data
Imports System.Windows.Controls
Imports System.Windows.Controls.Primitives
Imports DocumentFormat.OpenXml.Office2016.Drawing.ChartDrawing
Imports DPC.DPC.Components
Imports DPC.DPC.Data.Controllers
Imports DPC.DPC.Data.Helpers
Imports DPC.DPC.Data.Model
Imports MySql.Data.MySqlClient
Imports OfficeOpenXml.FormulaParsing.Ranges


Namespace DPC.Views.Stocks.Suppliers.ManageBrands
    Public Class ManageBrands
        Inherits UserControl

        Private popup As Popup
        Private recentlyClosed As Boolean = False
        Private view As ICollectionView

        Private _paginationHelper As PaginationHelper
        Private _searchFilterHelper As SearchFilterHelper

        Public Sub New(lblPageInfo As TextBlock)
            InitializeComponent()
            InitializeControls()
        End Sub

        Public Sub New()
            InitializeComponent()
            InitializeControls()
        End Sub

        Public Sub InitializeControls()
            dataGrid = TryCast(FindName("dataGrid"), DataGrid)
            txtSearch = TryCast(FindName("txtSearch"), TextBox)
            cboItemsPerPage = TryCast(FindName("cboItemsPerPage"), ComboBox)
            paginationPanel = TryCast(FindName("paginationPanel"), StackPanel)

            If dataGrid Is Nothing Then
                MessageBox.Show("DataGrid not found in the XAML.", "Initialization Error", MessageBoxButton.OK, MessageBoxImage.Error)
                Return
            End If

            If paginationPanel Is Nothing Then
                MessageBox.Show("Pagination panel not found in the XAML.", "Initialization Error", MessageBoxButton.OK, MessageBoxImage.Error)
                Return
            End If

            If txtSearch IsNot Nothing Then
                AddHandler txtSearch.TextChanged, AddressOf TxtSearch_TextChanged
            End If

            If cboItemsPerPage IsNot Nothing Then
                AddHandler cboItemsPerPage.SelectionChanged, AddressOf CboItemsPerPage_SelectionChanged
            End If

            LoadBrands()
        End Sub

        ' =======================================================
        ' NEW EVENT HANDLER: Auto-numbering the DataGrid rows
        ' =======================================================
        Private Sub dataGrid_LoadingRow(sender As Object, e As DataGridRowEventArgs) Handles dataGrid.LoadingRow
            e.Row.Header = (e.Row.GetIndex() + 1).ToString()
        End Sub

        Private Sub TxtSearch_TextChanged(sender As Object, e As TextChangedEventArgs)
            If _searchFilterHelper IsNot Nothing Then
                _searchFilterHelper.SearchText = txtSearch.Text
            End If
        End Sub

        Private Sub ExportToExcel(sender As Object, e As RoutedEventArgs)
            If dataGrid Is Nothing Then Return
            Dim columnsToExclude As New List(Of String) From {"Actions"}
            ExcelExporter.ExportDataGridToExcel(dataGrid, columnsToExclude, "BrandsExport", "Brands")
        End Sub

        Private Sub OpenAddBrand(sender As Object, e As RoutedEventArgs)
            Dim clickedButton As Button = TryCast(sender, Button)
            If clickedButton Is Nothing Then Return

            If recentlyClosed Then
                recentlyClosed = False
                Return
            End If

            If popup IsNot Nothing AndAlso popup.IsOpen Then
                popup.IsOpen = False
                recentlyClosed = True
                Return
            End If

            popup = New Popup With {
                .PlacementTarget = clickedButton,
                .Placement = PlacementMode.Bottom,
                .StaysOpen = False,
                .AllowsTransparency = True
            }

            Dim addBrandWindow As New DPC.Components.Forms.AddBrand()
            AddHandler addBrandWindow.BrandAdded, AddressOf OnBrandAdded
            popup.Child = addBrandWindow

            AddHandler popup.Closed, Sub()
                                         recentlyClosed = True
                                         Task.Delay(100).ContinueWith(Sub() recentlyClosed = False, TaskScheduler.FromCurrentSynchronizationContext())
                                     End Sub

            popup.IsOpen = True
        End Sub

        Private Sub OnBrandAdded()
            LoadBrands()
        End Sub

        Private Sub LoadBrands()
            Try
                If dataGrid Is Nothing Then
                    MessageBox.Show("DataGrid control not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Error)
                    Return
                End If

                Dim allBrands As ObservableCollection(Of Object)
                Try
                    Dim brandList = BrandController.GetBrands()
                    If brandList Is Nothing Then
                        MessageBox.Show("Brand data returned null.", "Data Error", MessageBoxButton.OK, MessageBoxImage.Warning)
                        allBrands = New ObservableCollection(Of Object)()
                    Else
                        allBrands = New ObservableCollection(Of Object)(brandList)
                    End If
                Catch ex As Exception
                    MessageBox.Show("Error retrieving brand data: " & ex.Message, "Data Error", MessageBoxButton.OK, MessageBoxImage.Error)
                    allBrands = New ObservableCollection(Of Object)()
                End Try

                paginationPanel.Children.Clear()
                _paginationHelper = New PaginationHelper(dataGrid, paginationPanel)

                If cboItemsPerPage IsNot Nothing Then
                    Dim selectedItem = TryCast(cboItemsPerPage.SelectedItem, ComboBoxItem)
                    If selectedItem IsNot Nothing Then
                        Dim itemsPerPageText As String = TryCast(selectedItem.Content, String)
                        Dim itemsPerPage As Integer
                        If Integer.TryParse(itemsPerPageText, itemsPerPage) Then
                            _paginationHelper.ItemsPerPage = itemsPerPage
                        End If
                    End If
                End If

                _paginationHelper.AllItems = allBrands

                _searchFilterHelper = New SearchFilterHelper(_paginationHelper, "ID", "Name", "Category", "SubCategory", "TotalSupplier")

            Catch ex As Exception
                MessageBox.Show("Error in LoadBrands: " & ex.Message & vbCrLf & "Stack Trace: " & ex.StackTrace,
                                "Error", MessageBoxButton.OK, MessageBoxImage.Error)
            End Try
        End Sub

        Public Sub LoadBrandData()
            Try
                Using conn As MySqlConnection = SplashScreen.GetDatabaseConnection()
                    conn.Open()
                    Dim query As String = "SELECT BrandID, BrandName, (SELECT COUNT(*) FROM supplier WHERE BrandID = brand.BrandID) AS TotalSuppliers FROM brand ORDER BY BrandName"

                    Using cmd As New MySqlCommand(query, conn)
                        Using adapter As New MySqlDataAdapter(cmd)
                            Dim dataTable As New DataTable()
                            adapter.Fill(dataTable)
                            dataGrid.ItemsSource = dataTable.DefaultView
                        End Using
                    End Using
                End Using
            Catch ex As Exception
                MessageBox.Show($"An error occurred while loading brand data: {ex.Message}")
            End Try
        End Sub

        Private Sub CboItemsPerPage_SelectionChanged(sender As Object, e As SelectionChangedEventArgs)
            If _paginationHelper Is Nothing Then Return

            Dim selectedComboBoxItem As ComboBoxItem = TryCast(cboItemsPerPage.SelectedItem, ComboBoxItem)
            If selectedComboBoxItem IsNot Nothing Then
                Dim itemsPerPageText As String = TryCast(selectedComboBoxItem.Content, String)
                Dim newItemsPerPage As Integer
                If Integer.TryParse(itemsPerPageText, newItemsPerPage) Then
                    _paginationHelper.ItemsPerPage = newItemsPerPage
                End If
            End If
        End Sub

        Private Sub OpenEditBrand(sender As Object, e As RoutedEventArgs)
            Dim clickedButton As Button = TryCast(sender, Button)
            If clickedButton Is Nothing Then Return

            If recentlyClosed Then
                recentlyClosed = False
                Return
            End If

            If popup IsNot Nothing AndAlso popup.IsOpen Then
                popup.IsOpen = False
                recentlyClosed = True
                Return
            End If

            popup = New Popup With {
                .PlacementTarget = clickedButton,
                .Placement = PlacementMode.Bottom,
                .StaysOpen = False,
                .AllowsTransparency = True
            }

            Dim brand As Brand = TryCast(dataGrid.SelectedItem, Brand)
            If brand Is Nothing Then Return

            Dim editBrandWindow As New DPC.Components.Forms.EditBrand()

            ' Set all properties BEFORE calling LoadData()
            editBrandWindow.TxtBrand.Text = brand.Name
            editBrandWindow.brandID = Convert.ToInt32(brand.ID)
            editBrandWindow.manageBrands = Me
            editBrandWindow.CategoryName = brand.Category
            editBrandWindow.SubCategoryName = brand.SubCategory

            ' Loads combos and pre-selects the correct category/subcategory
            editBrandWindow.LoadData()

            AddHandler editBrandWindow.BrandAdded, AddressOf OnBrandAdded

            popup.Child = editBrandWindow

            AddHandler popup.Closed, Sub()
                                         recentlyClosed = True
                                         Task.Delay(100).ContinueWith(Sub() recentlyClosed = False, TaskScheduler.FromCurrentSynchronizationContext())
                                     End Sub

            popup.IsOpen = True
        End Sub

        Private Sub DeleteBrand(sender As Object, e As RoutedEventArgs)
            Dim clickedButton As Button = TryCast(sender, Button)
            If clickedButton Is Nothing Then Return

            If recentlyClosed Then
                recentlyClosed = False
                Return
            End If

            If popup IsNot Nothing AndAlso popup.IsOpen Then
                popup.IsOpen = False
                recentlyClosed = True
                Return
            End If

            popup = New Popup With {
                .PlacementTarget = clickedButton,
                .Placement = PlacementMode.Center,
                .StaysOpen = False,
                .AllowsTransparency = True
            }

            Dim deleteBrandWindow As New DPC.Components.Forms.DeleteBrandPopup()

            Dim brand As Brand = TryCast(dataGrid.SelectedItem, Brand)

            deleteBrandWindow.brandName.Text = brand.Name
            deleteBrandWindow.brandID = brand.ID.ToString()
            deleteBrandWindow.manageBrands = Me

            popup.Child = deleteBrandWindow

            AddHandler popup.Closed, Sub()
                                         recentlyClosed = True
                                         Task.Delay(100).ContinueWith(Sub() recentlyClosed = False, TaskScheduler.FromCurrentSynchronizationContext())
                                     End Sub

            popup.IsOpen = True
        End Sub


    End Class
End Namespace