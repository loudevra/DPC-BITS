Imports System.Collections.ObjectModel
Imports DPC.DPC.Data.Controllers.Stocks
Imports DPC.DPC.Data.Model

Namespace DPC.Views.Stocks.ProductsLabel.CustomLabel
    ''' <summary>
    ''' Interaction logic for CustomLabel.xaml
    ''' </summary>

    Public Class CustomLabel
        Inherits UserControl

        Private _product As ObservableCollection(Of Product)
        Private _selectedProduct As New Product
        Private _warehouseID As Integer
        Private SerialNumberList As List(Of String)
        Private wrapPanel As New WrapPanel

        Public Sub New()
            InitializeComponent()

            LoadWarehouses()

        End Sub
        ' Trigger the default selection on window load
        Private Sub Window_Loaded(sender As Object, e As RoutedEventArgs)
            ' Set Add as the default checked radio button
            'AddProductName.IsChecked = True
            ' Apply styles accordingly
            'UpdateStyles(AddBorderProductName, AddIconProductName, "#456B2E", True)
            'UpdateStyles(AddBorderBusinessLocation, AddIconBusinessLocation, "#456B2E", True)
            'UpdateStyles(AddBorderWarehouse, AddIconWarehouse, "#456B2E", True)
            'UpdateStyles(AddBorderPrice, AddIconPrice, "#456B2E", True)
            'UpdateStyles(AddBorderProductCode, AddIconProductCode, "#456B2E", True)
            'UpdateStyles(AddBorderProducts, AddIconProducts, "#456B2E", True)
        End Sub

        ' General method to update styles
        'Private Sub UpdateStyles(border As Border, icon As MaterialDesignThemes.Wpf.PackIcon, color As String, isChecked As Boolean)
        '    If border IsNot Nothing AndAlso icon IsNot Nothing Then
        '        If isChecked Then
        '            Dim newColor As New SolidColorBrush(CType(ColorConverter.ConvertFromString(color), Color))
        '            border.BorderBrush = newColor
        '            icon.Foreground = newColor
        '        Else
        '            border.BorderBrush = Brushes.Black
        '            icon.Foreground = New SolidColorBrush(ColorConverter.ConvertFromString("#474747"))
        '        End If
        '    End If
        'End Sub

        ' Event Handlers
        Private Sub LoadWarehouses()
            Dim warehouse = StocksLabelController.GetWarehouse()
            cmbWarehouses.ItemsSource = warehouse
            cmbWarehouses.DisplayMemberPath = "Value"
            cmbWarehouses.SelectedValuePath = "Key"
        End Sub

        Private Sub searchProducts(sender As Object, e As TextChangedEventArgs)

            _product = StocksLabelController.SearchProducts(txtProducts.Text, _warehouseID)

            LstItems.ItemsSource = _product

            ' Show popup if we have results
            AutoCompletePopup.IsOpen = _product.Count > 0

            ' Adjust popup width to match the textbox
            AutoCompletePopup.Width = txtProducts.ActualWidth
        End Sub

        Private Sub LstItems_SelectionChanged(sender As Object, e As SelectionChangedEventArgs)
            If LstItems.SelectedItem IsNot Nothing Then
                _selectedProduct = CType(LstItems.SelectedItem, Product)
                txtProducts.Text = _selectedProduct.ProductName
                AutoCompletePopup.IsOpen = False

                ' Store serial numbers
                SerialNumberList = StocksLabelController.GetSerialNumber(_selectedProduct.ProductID)

                ' DEBUG: Show what was retrieved
                MessageBox.Show($"Product: {_selectedProduct.ProductName}" & vbCrLf &
                               $"Product ID: {_selectedProduct.ProductID}" & vbCrLf &
                               $"Serial Numbers Found: {If(SerialNumberList IsNot Nothing, SerialNumberList.Count.ToString(), "NULL")}",
                               "Debug Info", MessageBoxButton.OK, MessageBoxImage.Information)
            End If
        End Sub

        Private Sub ItemsFromWarehouse(sender As Object, e As SelectionChangedEventArgs)
            _warehouseID = CType(cmbWarehouses.SelectedValue, Integer)
            _selectedProduct = Nothing
            txtProducts.Clear()
        End Sub
        Private Function MmToDiu(mm As Double) As Double
            Return mm * 96 / 25.4
        End Function

        Private Function CreateBarcodePanel(code As String) As StackPanel
            Dim _width = MmToDiu(barcodeWidth.Text)
            Dim _height = MmToDiu(barcodeHeight.Text)
            Dim _lblWidth = MmToDiu(lblWidth.Text)
            Dim _lblHeight = MmToDiu(lblHeight.Text)

            Dim sizeString As String = cmbFontSize.Text.Replace("pt", "")
            Dim fontSizeDouble As Double = CType(sizeString, Double)

            Dim productLabel As New TextBlock With {
        .Width = _lblWidth,
        .Height = _lblHeight,
        .TextWrapping = TextWrapping.Wrap,
        .FontSize = fontSizeDouble,
        .Text = _selectedProduct.ProductName,
        .VerticalAlignment = VerticalAlignment.Center,
        .HorizontalAlignment = HorizontalAlignment.Center,
        .TextAlignment = TextAlignment.Center,
        .Margin = New Thickness(0, 2, 0, 0)
    }

            Dim ProductCodeLabel As New TextBlock With {
        .Width = _lblWidth,
        .FontSize = fontSizeDouble,
        .Text = _selectedProduct.ProductCode,
        .VerticalAlignment = VerticalAlignment.Center,
        .HorizontalAlignment = HorizontalAlignment.Center,
        .TextAlignment = TextAlignment.Center,
        .Margin = New Thickness(0, 2, 0, 0)
    }
            Dim imageSource As BitmapImage = StocksLabelController.GenerateBarcode(code, _width, _height, barcodeType.SelectedIndex)
            Dim barcodeImage As New System.Windows.Controls.Image

            If imageSource IsNot Nothing Then
                barcodeImage.Source = imageSource
                barcodeImage.Height = _height
                barcodeImage.Width = _width
                barcodeImage.Margin = New Thickness(0, 2, 0, 0)
                barcodeImage.VerticalAlignment = VerticalAlignment.Center
                barcodeImage.Stretch = Stretch.None
                barcodeImage.HorizontalAlignment = HorizontalAlignment.Stretch
            Else
                MessageBox.Show("Failed to generate barcode image. Please check the code format.", "Error", MessageBoxButton.OK, MessageBoxImage.Error)
                Dim nullPanel As New StackPanel
                Return nullPanel
            End If

            Dim barcodeLabel As New TextBlock With {
        .Width = _lblWidth,
        .FontSize = fontSizeDouble,
        .Text = code,
        .VerticalAlignment = VerticalAlignment.Center,
        .HorizontalAlignment = HorizontalAlignment.Center,
        .TextAlignment = TextAlignment.Center,
        .Margin = New Thickness(0, 2, 0, 0)
    }

            Dim retailPrice As New TextBlock With {
        .TextWrapping = TextWrapping.Wrap,
        .FontSize = fontSizeDouble,
        .Text = "₱ " + _selectedProduct.RetailPrice.ToString("N2"),
        .VerticalAlignment = VerticalAlignment.Center,
        .HorizontalAlignment = HorizontalAlignment.Center,
        .TextAlignment = TextAlignment.Center,
        .Margin = New Thickness(0, 2, 0, 0)
    }

            Dim warehouseLabel As New TextBlock With {
        .Width = _lblWidth,
        .FontSize = fontSizeDouble,
        .TextWrapping = TextWrapping.Wrap,
        .Text = cmbWarehouses.Text,
        .VerticalAlignment = VerticalAlignment.Center,
        .HorizontalAlignment = HorizontalAlignment.Center,
        .TextAlignment = TextAlignment.Center,
        .Margin = New Thickness(0, 2, 0, 0)
    }

            Dim sp As New StackPanel With {
        .Background = New SolidColorBrush(Colors.White),
        .Margin = New Thickness(0, 0, 4, 0)
    }

            If includeProductName.IsChecked Then
                sp.Children.Add(productLabel)
            End If
            If includeProductCode.IsChecked Then
                sp.Children.Add(ProductCodeLabel)
            End If
            sp.Children.Add(barcodeImage)
            sp.Children.Add(barcodeLabel)
            If includePrice.IsChecked Then
                sp.Children.Add(retailPrice)
            End If
            If includeWarehouse.IsChecked Then
                sp.Children.Add(warehouseLabel)
            End If

            Return sp
        End Function

        Private Sub PrintBarcodes(sender As Object, e As RoutedEventArgs)
            ' Add validation with user feedback
            If _selectedProduct Is Nothing Then
                MessageBox.Show("Please select a product first.", "No Product Selected", MessageBoxButton.OK, MessageBoxImage.Warning)
                Exit Sub
            End If

            If SerialNumberList Is Nothing OrElse SerialNumberList.Count = 0 Then
                MessageBox.Show("No serial numbers found for the selected product.", "No Serial Numbers", MessageBoxButton.OK, MessageBoxImage.Warning)
                Exit Sub
            End If

            If cmbWarehouses.SelectedValue Is Nothing Then
                MessageBox.Show("Please select a warehouse.", "No Warehouse Selected", MessageBoxButton.OK, MessageBoxImage.Warning)
                Exit Sub
            End If

            ' Clear UI
            wrapPanel.Children.Clear()
            testBorder.Child = Nothing

            ' Copy count setup
            Dim copyCount As Integer = 1
            If Not Integer.TryParse(copies.Text, copyCount) OrElse copyCount < 1 Then
                copies.Text = "1"
                copyCount = 1
            End If

            ' Container for multiple pages
            Dim containerPanel As New StackPanel With {.Orientation = Orientation.Vertical}
            Dim pageHeightLimit As Double = 1122.52 ' A4 height
            Dim pageWidth As Double = 793.7 ' A4 width

            ' Initialize first page
            Dim currentWrapPanel As New WrapPanel With {.Width = pageWidth}
            Dim currentBorder As New Border With {
                .Background = New SolidColorBrush(Colors.White),
                .Padding = New Thickness(30),
                .Margin = New Thickness(0, 0, 0, 10),
                .Width = pageWidth,
                .Child = currentWrapPanel
            }

            ' Use testBorder to measure page height
            testBorder.Child = currentBorder
            testBorder.Measure(New Size(pageWidth, 5000))
            testBorder.Arrange(New Rect(0, 0, pageWidth, 5000))
            testBorder.UpdateLayout()

            For i As Integer = 0 To copyCount - 1
                For Each serialNumber As String In SerialNumberList
                    Dim panel = CreateBarcodePanel(serialNumber)
                    currentWrapPanel.Children.Add(panel)

                    ' Update layout to check overflow
                    testBorder.UpdateLayout()

                    If testBorder.ActualHeight > pageHeightLimit Then
                        ' Remove overflowing panel
                        currentWrapPanel.Children.Remove(panel)

                        ' Disconnect from testBorder before adding to container
                        testBorder.Child = Nothing
                        containerPanel.Children.Add(currentBorder)

                        ' Start a new page
                        currentWrapPanel = New WrapPanel With {.Width = pageWidth}
                        currentWrapPanel.Children.Add(panel)

                        currentBorder = New Border With {
                            .Background = New SolidColorBrush(Colors.White),
                            .Padding = New Thickness(30),
                            .Margin = New Thickness(0, 0, 0, 10),
                            .Width = pageWidth,
                            .Child = currentWrapPanel
                        }

                        testBorder.Child = currentBorder
                        testBorder.UpdateLayout()
                    End If
                Next
            Next

            ' Add last page if it has content
            If currentWrapPanel.Children.Count > 0 Then
                testBorder.Child = Nothing
                containerPanel.Children.Add(currentBorder)
            End If

            ' Show preview
            Dim lblPreview As New LabelPrintPreview(containerPanel)
            lblPreview.ShowDialog()
        End Sub



        'Product Name
        'Private Sub Add_CheckedProductName(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderProductName, AddIconProductName, "#456B2E", True)
        'End Sub

        'Private Sub Add_UncheckedProductName(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderProductName, AddIconProductName, "#456B2E", False)
        'End Sub

        'Private Sub Remove_CheckedProductName(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderProductName, RemoveIconProductName, "#D23636", True)
        'End Sub

        'Private Sub Remove_UncheckedProductName(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderProductName, RemoveIconProductName, "#D23636", False)
        'End Sub

        ''Business Location
        'Private Sub Add_CheckedBusinessLocation(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderBusinessLocation, AddIconBusinessLocation, "#456B2E", True)
        'End Sub

        'Private Sub Add_UncheckedBusinessLocation(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderBusinessLocation, AddIconBusinessLocation, "#456B2E", False)
        'End Sub

        'Private Sub Remove_CheckedBusinessLocation(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderBusinessLocation, RemoveIconBusinessLocation, "#D23636", True)
        'End Sub

        'Private Sub Remove_UncheckedBusinessLocation(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderBusinessLocation, RemoveIconBusinessLocation, "#D23636", False)
        'End Sub

        ''Warehouse
        'Private Sub Add_CheckedWarehouse(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderWarehouse, AddIconWarehouse, "#456B2E", True)
        'End Sub

        'Private Sub Add_UncheckedWarehouse(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderWarehouse, AddIconWarehouse, "#456B2E", False)
        'End Sub

        'Private Sub Remove_CheckedWarehouse(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderWarehouse, RemoveIconWarehouse, "#D23636", True)
        'End Sub

        'Private Sub Remove_UncheckedWarehouse(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderWarehouse, RemoveIconWarehouse, "#D23636", False)
        'End Sub

        ''Price
        'Private Sub Add_CheckedPrice(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderPrice, AddIconPrice, "#456B2E", True)
        'End Sub

        'Private Sub Add_UncheckedPrice(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderPrice, AddIconPrice, "#456B2E", False)
        'End Sub

        'Private Sub Remove_CheckedPrice(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderPrice, RemoveIconPrice, "#D23636", True)
        'End Sub

        'Private Sub Remove_UncheckedPrice(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderPrice, RemoveIconPrice, "#D23636", False)
        'End Sub

        ''Product Code
        'Private Sub Add_CheckedProductCode(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderProductCode, AddIconProductCode, "#456B2E", True)
        'End Sub

        'Private Sub Add_UncheckedProductCode(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderProductCode, AddIconProductCode, "#456B2E", False)
        'End Sub

        'Private Sub Remove_CheckedProductCode(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderProductCode, RemoveIconProductCode, "#D23636", True)
        'End Sub

        'Private Sub Remove_UncheckedProductCode(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderProductCode, RemoveIconProductCode, "#D23636", False)
        'End Sub

        ''Products
        'Private Sub Add_CheckedProducts(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderProducts, AddIconProducts, "#456B2E", True)
        'End Sub

        'Private Sub Add_UncheckedProducts(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(AddBorderProducts, AddIconProducts, "#456B2E", False)
        'End Sub

        'Private Sub Remove_CheckedProducts(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderProducts, RemoveIconProducts, "#D23636", True)
        'End Sub

        'Private Sub Remove_UncheckedProducts(sender As Object, e As RoutedEventArgs)
        '    UpdateStyles(RemoveBorderProducts, RemoveIconProducts, "#D23636", False)
        'End Sub

    End Class
End Namespace