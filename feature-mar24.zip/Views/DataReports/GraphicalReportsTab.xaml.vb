﻿Namespace DPC.Views.DataReports

    Public Class GraphicalReportsTab
        Private Sub New()
            InitializeComponent()
        End Sub

        ' This is where you can code for the function
    End Class
End Namespace
