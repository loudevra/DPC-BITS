﻿Namespace DPC.Views.DataReports.Statements
    Public Class DTRTabStructured
        Public Sub New()
            InitializeComponent()
        End Sub

        ' This is where you can code for the function
    End Class
End Namespace